<?php
// src/Service/MessageGenerator.php
namespace App\Service;
use Psr\Log\LoggerInterface;

class MessageGenerator
{
    private $logger;

    public function __construct(LoggerInterface $logger)
    {
        $this->logger = $logger;
    }

    public function getHappyMessage(): string
    {   
        $messages = [
            'Bu bir bildirim mesajidir!',
            'Bu bir mesajdir!',
            'Mesaj!',
        ];

        $this->logger->info('Bu bir bildirim mesajidir!');

        $index = array_rand($messages);

        return $messages[$index];
    }
}