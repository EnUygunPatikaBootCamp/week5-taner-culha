<?php
// src/Controller/LuckyController.php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use App\Service\MessageGenerator;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class LuckyController extends AbstractController
{
    /**
    ** @Route("/lucky/number/{max}", name="app_lucky_number")    
    */
    public function number(int $max, MessageGenerator $messageGenerator): Response
    {
        $number= random_int(0, $max);
        $message=$messageGenerator->getHappyMessage();
        return new Response(
            '<html><body>Mesaj Metni: '.$message.'</body></html>'
        );
    }

    /**
    ** @Route("/lucky/jsonresponse/{max}", name="app_jsonresponse")    
    */
    public function jsonResponse(int $max): Response{
        $number= random_int(0,$max);
        $response = new Response();
        $response->setContent(json_encode([
            'data'=>123,
         ]));
         $response->headers->set('Content-Type'. 'application\json');
         return $response;
    }
}