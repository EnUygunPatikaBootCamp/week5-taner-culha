<?php
// src/Controller/UserController.php
namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class UserController extends AbstractController
{
    /**
    ** @Route("/notifications", name="notifications")    
    */
    public function notifications(): Response
    {
        // get the user information and notifications somehow
        $userFirstName = 'Taner Culha';
        $userNotifications = [
            array('name'=>'Kayit basarili','date'=>'2022'),
            array('name'=>'Sisteme hos geldiniz.','date'=>'2023')
        ];

        //print_r("<pre>"); var_dump($userNotifications); exit;

        // the template path is the relative file path from `templates/`
        return $this->render('user/notifications.html.twig', [
            // this array defines the variables passed to the template,
            // where the key is the variable name and the value is the variable value
            // (Twig recommends using snake_case variable names: 'foo_bar' instead of 'fooBar')
            'user_first_name' => $userFirstName,
            'notifications' => $userNotifications,
        ]);
    }
}